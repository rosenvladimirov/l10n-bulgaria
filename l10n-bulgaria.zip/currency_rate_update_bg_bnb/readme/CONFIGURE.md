[ This file is optional, it should explain how to configure
  the module before using it; it is aimed at advanced users. ]

To configure this module, you need to:

- Go to ...

![alternative description]()../static/description/image.png)
