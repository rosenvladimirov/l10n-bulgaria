[ This file must only be present if there are very specific
  installation instructions, such as installing non-python
  dependencies. The audience is systems administrators. ]

To install this module, you need to:

1. Do this ...
