#  Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import res_config
from . import res_partner
from . import res_company
from . import res_country
from . import account_account_tag
from . import account_move
