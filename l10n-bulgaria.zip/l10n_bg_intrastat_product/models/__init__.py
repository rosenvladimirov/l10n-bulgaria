# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_move
from . import res_company
from . import l10n_bg_intrastat_product_declaration
from . import res_city
from . import product
from . import intrastat_region
