[ This file is optional, it should explain how to configure
  the module before using it; it is aimed at advanced users. ]

To configure this module, you need to:

- Go to Configuration -> Accounting -> Intrastat and choice the Country of transport by default, On Arrivals and Dispatches: choice Extended.
