[ This file is optional but strongly suggested to allow end-users to evaluate the
module's usefulness in their context. ]

This module used for Intrastat reporting:

- Before generate the declaration, please on invoce fill all needed information linked with Intrastat, Generate the Intrastat data rows.
- Please be sure the Partners is correct configured, check the Fiscal position, Country in Partner fields. The Intrastat used only for deal in EU.

The related modules:

- modules it depends on and their features:
  - Intrastat product (OCA)
  - Intrastat h.s. code import
- other modules that can work well together with this one is Bulgarian localation and multilingual support:
  - Bulgarian city
  - Partner multilingual
