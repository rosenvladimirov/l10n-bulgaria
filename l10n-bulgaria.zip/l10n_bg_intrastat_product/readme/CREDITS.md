[ This file is optional and contains additional credits, other than
  authors, contributors, and maintainers. ]

The development of this module has been financially supported by:

- 2019-2023 BioPrint Ltd.
- 2018-2019 dXFactory
