[ This file must be max 2-3 paragraphs, and is required. ]

This module extends the functionality of intrastat product module to support Bulgarian Intrastat declaration.
and to allow you to export in xml file to use when report in NRA https://portal.nra.bg/
In module included translation of intrastat nomenclature, and added the regions in Bulgaria.
