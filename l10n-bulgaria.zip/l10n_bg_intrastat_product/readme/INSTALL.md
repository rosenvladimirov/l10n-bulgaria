[ This file must only be present if there are very specific
  installation instructions, such as installing non-python
  dependencies. The audience is systems administrators. ]

To install this module, you need to:

1. WARNING: This module conflicts with the Intrastat modules from the official enterprise addons. If you have already installed these modules, you should uninstall them before installing this module.

You need to add HS product codes for your company through the installation wizard. It's automatically launched if installing the module from the UI.

If any other installation method is used, you can go to Settings > Technical > Actions > Configuration Wizards on developer mode, and launch there the wizard called "Load Intrastat Codes". The Bulgarian translation already stored in installation wizard. Please reload again wizard to update translations.
