# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import res_partner
from . import res_country
from . import res_currency
from . import res_bank
from . import resource
from . import stock_warehouse
from . import hr_employee
