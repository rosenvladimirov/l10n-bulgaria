# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import models
from . import wizard
from .hooks import post_load_hook
