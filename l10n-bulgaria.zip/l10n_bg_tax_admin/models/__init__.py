# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import chart_template
from . import account_account
from . import res_currency
from . import account_journal
from . import account_tax
from . import account_move
from . import account_move_line
from . import l10n_bg_protocol_account_move
from . import l10n_bg_report_sale_account_move
from . import l10n_bg_customs_account_move
from . import partner
from . import product_category
from . import product_product
from . import product_template
from . import company
