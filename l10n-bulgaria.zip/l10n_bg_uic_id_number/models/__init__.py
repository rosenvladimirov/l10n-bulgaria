from . import res_partner
from . import res_partner_id_category
