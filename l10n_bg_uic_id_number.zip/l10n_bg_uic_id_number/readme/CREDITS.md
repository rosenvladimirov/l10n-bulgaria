[ This file is optional and contains additional credits, other than
  authors, contributors, and maintainers. ]

The development of this module has been financially supported by:

- Company 1 name
- Company 2 name
